rm -f ./ex00/Tyrion.class.php
rm -f ./ex01/Greyjoy.class.php
rm -f ./ex02/Targaryen.class.php
rm -f ./ex03/House.class.php
rm -f ./ex04/Lannister.class.php
rm -f ./ex04/Jaime.class.php
rm -f ./ex04/Tyrion.class.php
rm -f ./ex05/IFighter.class.php
rm -f ./ex05/NightsWatch.class.php
rm -f ./ex06/Fighter.class.php
rm -f ./ex06/UnholyFactory.class.php

rm -f ./ex0*/myres