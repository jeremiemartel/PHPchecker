echo ---- ex01 ----

php test.php > myres
diff res myres
