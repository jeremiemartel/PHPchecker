php test1.php > myres

echo ---- ex01 ----

diff res myres
echo Test2 ex01
    php test2.php


