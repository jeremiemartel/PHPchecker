<?php

include('Euron.class.php');

$euron = new Euron();

print($euron->familyMotto . PHP_EOL);

?>

