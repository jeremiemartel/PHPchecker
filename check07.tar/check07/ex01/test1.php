<?php

include('Euron.class.php');

$euron = new Euron();

$euron->announceMotto();

?>
