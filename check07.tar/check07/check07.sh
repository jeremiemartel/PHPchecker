path="../d07"

cp $path/ex00/Tyrion.class.php ./ex00/

cp $path/ex01/Greyjoy.class.php ./ex01/

cp $path/ex02/Targaryen.class.php ./ex02/

cp $path/ex03/House.class.php ./ex03/

cp $path/ex04/Lannister.class.php ./ex04/
cp $path/ex04/Jaime.class.php ./ex04/
cp $path/ex04/Tyrion.class.php ./ex04/

cp $path/ex05/IFighter.class.php ./ex05/
cp $path/ex05/NightsWatch.class.php ./ex05/

cp $path/ex06/Fighter.class.php ./ex06/
cp $path/ex06/UnholyFactory.class.php ./ex06/

cd ./ex00

for path in "ex00" "ex01" "ex02" "ex03" "ex04" "ex05" "ex06"
do
    cd ../$path;
    ./launch.sh
done
