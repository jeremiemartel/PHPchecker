php test1.php > myres
echo ---- ex06 ----
diff res myres
echo Test2 ex06
    php test2.php


