php test1.php > myres

echo ---- ex03 ----
diff res myres
echo Test2 ex03
    php test2.php
